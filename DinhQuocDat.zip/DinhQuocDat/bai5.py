cannang=float(input("Nhập cân nặng: "))
chieucao=float(input("Nhập chiều cao: "))
BMI = cannang/(chieucao**2)
if BMI<18.5:
    print("Gầy")
elif 18.5<=BMI<=24.9:
    print("Bình thường")
elif 25<=BMI<=29.9:
    print("Thừa cân")
else:
    print("Béo phì")