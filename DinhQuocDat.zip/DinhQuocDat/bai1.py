n = int(input("Nhập số nguyên N "))
if n > 0:
    print("N là số dương")
elif n == 0:
    print("N là số 0")
else:
    print("N là số âm")
