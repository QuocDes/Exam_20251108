N=int(input("Nhập số tuổi của người: "))
if N<12:
    print("Trẻ em")
elif N<=17:
    print("Thiếu niên")
elif N<=59:
    print("Nguời trưởng thành")
else:
    print("Người cao tuổi")