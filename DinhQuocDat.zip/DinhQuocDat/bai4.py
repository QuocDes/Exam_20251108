N=int(input("Số điểm của học sinh: "))
if 8.5<=N<=10:
    print("Xếp hạng A")
elif 7<=N<8.5:
    print("Xếp hạng B")
elif 5<=N<7:
    print("Xếp hạng C")
else:
    print("Xêp hạng D")